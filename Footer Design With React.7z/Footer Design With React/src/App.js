import React from 'react';
import { FooterContainer } from './containers/footer'

function App() {
  return (
   <>
    <FooterContainer />
   </>
  );
}

export default App;
